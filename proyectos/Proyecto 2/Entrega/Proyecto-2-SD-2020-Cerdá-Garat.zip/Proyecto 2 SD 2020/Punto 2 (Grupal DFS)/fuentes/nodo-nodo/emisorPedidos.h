/* Archivo SocketNodos.h */
#ifndef EMISORPEDIDOS_H
#define EMISORPEDIDOS_H

extern int emisorPedidosNodo(char* ip, char* route, char* destino,int opcion) ;

#endif /* EMISORPEDIDOS_H */
