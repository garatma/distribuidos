/* Archivo SocketNodos.h */
#ifndef RECEPTORPEDIDOS_H
#define RECEPTORPEDIDOS_H
/* #include "protocolo.h" */
extern void * receptorPedidosNodo(void *);

#endif /* RECEPTORPEDIDOS_H */
