#define DADOS 5
#define CARAS 6
#define TIROS 3

#define ARCHIVO_GLADE          "Generala.glade"
#define CANTIDAD_RECARGAS       2
#define CANTIDAD_CATEGORIAS     11 // 1 2 3 4 5 6 escalera full poker generala generala doble
#define PUNTAJE_ESCALERA        20
#define PUNTAJE_FULL            30
#define PUNTAJE_POKER           40
#define PUNTAJE_GENERALA        50
#define PUNTAJE_GENERALA_DOBLE  100
#define INDICE_UNO              0
#define INDICE_ESCALERA         6
#define INDICE_FULL             7
#define INDICE_POKER            8
#define INDICE_GENERALA         9
#define INDICE_GENERALA_DOBLE   10
#define LONGITUD_CADENA         100
