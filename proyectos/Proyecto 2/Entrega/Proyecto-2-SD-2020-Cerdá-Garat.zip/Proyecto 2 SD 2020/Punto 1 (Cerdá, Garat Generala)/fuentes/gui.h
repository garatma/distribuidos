#ifndef GUI
#define GUI 

#include "constantes.h"

extern void inicializar_gui(int *, char ***);
extern void * activar_gui(int, int);
extern void * actualizar_dados(int, int [DADOS]);
extern void * puntaje_total_remoto(int);

#endif /* ifndef GUI */

