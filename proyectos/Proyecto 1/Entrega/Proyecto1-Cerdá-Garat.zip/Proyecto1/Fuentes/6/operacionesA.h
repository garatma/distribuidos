#include "constantes.h"

int turno_licencia_matrimonio();
void informacion_partida_nacimiento(int, char *);
int turno_inscripcion_recien_nacido();
void inicializar_lista_partidas_nacimiento();
