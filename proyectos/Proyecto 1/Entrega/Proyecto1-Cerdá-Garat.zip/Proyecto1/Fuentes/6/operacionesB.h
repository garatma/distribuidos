#include "constantes.h"

int turno_patentar_auto();
int turno_transferencia_vehiculo();
void informacion_dominio(int, char *);
void inicializar_lista_dominios();
